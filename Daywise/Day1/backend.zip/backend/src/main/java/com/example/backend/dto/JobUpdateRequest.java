package com.example.backend.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
public class JobUpdateRequest {
    private String job;
    private int sala;
}
