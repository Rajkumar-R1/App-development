package com.example.backend.config;

public class CorsConfig {
    
}
